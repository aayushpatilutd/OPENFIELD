# InvoiceHub

A standalone, centralized accounts-payable portal. It is a clone of the AP
module from the customer portal, rebuilt as its own application and extended
with API credential management, QuickBooks bill creation, statement-to-QBO
reconciliation, a per-vendor Excel export, and a scheduled agent framework.

It does not share a database, a codebase or a deployment with the customer
portal. Nothing here touches that system.

---

## The cycle it runs

```
  vendors are set up once, with the rules for how their post arrives
    ↓
  the AP mailbox is swept, every attachment files itself     (Microsoft Graph)
    ↓
  the PDFs are read into invoices and statement lines        (Claude)
    ↓
  parsed invoices are pushed as bills                        (QuickBooks Online)
    ↓
  statements are reconciled against QBO's open bills
    ↓
  a workbook comes out — one tab per vendor — plus a payment plan
```

ServiceTitan is optional and does one job: when an invoice carries a PO
number, the job it belongs to is looked up and written onto the invoice.

---

## Running it

```bash
cd invoice-hub
./run.sh                      # or run.bat on Windows
```

Then <http://localhost:5100> and sign in with
`admin@invoicehub.local` / `changeme`. **Change that password immediately** —
the portal holds API credentials for four systems and the UI will nag until
you do.

It starts in **demo mode**, already full of data. Every integration returns
canned responses and no live API call is made, so you can click through the
whole cycle before connecting anything.

### Docker

```bash
docker build -t invoicehub .
docker run -p 5100:5100 -v invoicehub-data:/data invoicehub
```

Run **one worker only**. APScheduler lives in-process, so a second worker runs
every scheduled agent twice.

---

## Connecting the real systems

Settings → each integration has its own panel with a **Test connection**
button that tells you what actually happened rather than just failing.
Credentials are stored encrypted in the database, not in a config file, so
they survive a redeploy and can be changed without one. `.env` works too and
is the right choice for containers; anything saved in the UI overrides it.

| System | What it needs | What it gives you |
|---|---|---|
| **Microsoft Graph** | tenant, client ID, secret, AP mailbox | mailbox sweep, outbound email |
| **QuickBooks Online** | client ID, secret, realm, then press Connect | bill creation, the open-bill mirror |
| **ServiceTitan** | tenant, client ID, secret, app key | PO → job linkage |
| **Claude** | an API key | reads every PDF |

The Graph app registration needs **application** permissions `Mail.Read` and
`Mail.Send`, admin-consented. QuickBooks uses OAuth2; the refresh token
rotates and is re-saved automatically on every refresh.

Turn demo mode off in Settings once the credentials are in.

---

## Design decisions worth knowing

**A document, an invoice, a statement line and a QBO bill are four different
things**, even when they describe the same money. Each keeps its own row.
Collapsing them is what makes AP tools lie; the match table is where they are
brought together, so when the three disagree you can see all three side by
side.

**Every invoice number seen in any source becomes a row.** The obvious
implementation iterates the statement and looks each line up — which makes a
bill sitting in QBO that is on nobody's statement invisible. That is exactly
the bill that gets paid twice. Here it surfaces as `qbo_only`.

**Invoice numbers are normalised, then folded.** `ABC-000001` on the PDF,
`1` on the statement and `INV-000001` in QBO are one invoice. The folding
is deliberately narrow — same vendor, identical digits, exactly one bare
number and one prefix — because merging two genuinely different invoices is
far worse than leaving a pair unmerged. Ambiguous cases are logged, not
guessed.

**Agents never send email.** Ones that would write to a vendor produce a draft
and stop. A person opens Drafts, reads it, presses send. An AP agent with a
live mailbox will eventually chase a supplier for an invoice you already paid,
and you will hear about it from the supplier rather than from your software.

**Pushing a bill is conservative.** Refused if the invoice has no number, if
the vendor is not linked to a QBO vendor, if the parse was low confidence, or
if QBO already has that DocNumber for that vendor. A duplicate bill is quiet:
nothing downstream flags it, the vendor cashes both, and it surfaces months
later as an unexplained credit.

**The parser is allowed to say it is unsure.** A document that comes back low
confidence is marked `needs_review` and will not auto-push. A flagged bad read
costs a glance; a confident wrong total costs a payment run.

---

## The verdicts

| Verdict | Meaning | Default action |
|---|---|---|
| `matched` | all three agree | pay |
| `matched_no_doc` | statement and QBO agree, no invoice on file | pay |
| `credit` | a credit note, payment or overpayment | deduct |
| `amount_mismatch` | they disagree on how much | query — never pay |
| `missing_bill` | on their statement, we hold it, QBO doesn't know | hold |
| `missing_invoice` | on their statement and in QBO, no document | query |
| `missing_statement` | in QBO and we hold it, not on their statement | hold |
| `invoice_only` | we hold a document nobody else knows about | hold |
| `statement_only` | they claim it, we have nothing | query |
| `qbo_only` | open in our books, on no statement, no document | hold |
| `paid` | QBO shows it settled | ignore |

---

## The workbook

Reports → Build. You get:

- **Summary** — the month in figures, by vendor, with live total formulas
- **Payment plan** — what to pay each vendor, by method, with held items named
- **Exceptions** — every unresolved disagreement, colour-coded
- **One tab per vendor** — their terms, whether they sent a statement, every
  invoice number with all three amounts side by side, and a
  statement-less-QBO difference line

Sheet names are truncated to Excel's 31-character limit and de-duplicated, so
two vendors whose names collide when truncated both still get a tab.

---

## Agents

Eight ship built in, **all disabled**, because a fresh install should not start
emailing anyone. Enable what you want in Agents, or write your own — the
schedule lives in the database, so adding "chase Company ABC on the 2nd" is a
form, not a deploy.

| Agent | Default schedule |
|---|---|
| Mailbox sweep | every 30 minutes |
| Parse the backlog | hourly |
| Sync QuickBooks | daily 06:00 |
| Push approved bills | daily 07:00 |
| Month-end statement request | the 2nd at 08:00 |
| Chase missing invoices | Mondays 09:00 |
| Run the match | daily 06:30 |
| Month-end report | the 3rd at 10:00 |

All times UTC.

---

## Roles

| Role | Can |
|---|---|
| `viewer` | read |
| `clerk` | read, edit, upload, parse |
| `approver` | the above, plus send email and push bills |
| `admin` | everything, including API credentials and users |

---

## Demo data

The demo set exists to answer hard questions rather than dodge them. It
includes, deliberately: an amount mismatch, a one-cent difference that must
still match, a missing bill, a missing invoice, a statement-only claim, a
QBO-only bill, an invoice nobody else knows about, a credit note, a partial
payment, an already-paid bill, the same invoice number written three ways
across three systems, a duplicate attachment, a zero-byte attachment, mail
from an unknown sender, a vendor who sent no statement, a low-confidence scan,
a foreign-currency vendor, a finance charge with no invoice number, a
zero-amount line, a stale invoice from two periods back, a vendor not linked
to QuickBooks, and two vendors whose names collide at Excel's 31-character
sheet-name limit.

Reload it any time from Settings.

---

## Tests

```bash
python tests/smoke.py
```

95 checks against a throwaway database: every page renders, every API route
answers, the whole AP cycle runs, the guard rails refuse what they should, the
workbook builds with correct tabs, and a masked secret posted back from the UI
does not overwrite the stored credential.

---

## Layout

```
app.py              routes and the API
auth.py             sessions, roles, decorators
config.py           credential catalogue, encryption
db.py               schema and data access
wsgi.py             gunicorn entry point

core/
  util.py           normalisation, dates, money, vendor matching
  intake.py         mailbox sweep, upload, filing
  parsing.py        documents → invoices and statement lines
  matching.py       the three-way reconciliation
  billing.py        pushing bills to QuickBooks
  reporting.py      the per-vendor workbook
  agents.py         the agent framework and scheduler

integrations/
  graph.py          Microsoft Graph
  qbo.py            QuickBooks Online
  servicetitan.py   ServiceTitan
  claude_api.py     Claude

demo/
  fixtures.py       the edge-case dataset
  seed.py           loads it

templates/, static/, tests/
```

Each integration has a demo double alongside the real client, selected at
runtime by the `demo_mode` setting. That is why the whole portal is clickable
with no credentials at all.

---

## Known limits

- SQLite. Fine for a few thousand rows a month; the schema avoids
  SQLite-only types so moving to Postgres is a dialect change, not a redesign.
- One process. The scheduler is in-process, so scale up rather than out, or
  move the agents to an external runner.
- Demo documents are records without files behind them, so "download file"
  on a demo document has nothing to serve. Real uploads and swept
  attachments are written to `storage/`.
- Back up `.fernet_key`. Lose it and every stored credential becomes
  unreadable and has to be re-entered.
